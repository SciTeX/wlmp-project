<?php
//// -- SETTINGS FILE -- ////

/***#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-#***\
\ W |     WLMP PROJECT - Portal System v1.0     | W /
/ L | - - - - - - - - - - - - - - - - - - - - - | L \
\ M |          Copyright (C) 2006-2009.         | M /
/ P |      WLMP Project TEAM / D-Club Soft.     | P \
\***#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-#***/

/* -- INCLUDE CORE -- */
include("include/wlmp.php");

if ($lng == "1") {
  $page_title = "Settings";
} else {
  $page_title = "Be�ll�t�sok";
}

stdhead();

$curdir = getcwd();
$two_dir_up = ereg_replace("\\HTDOCS\\\\WLMP-Test", "", $curdir);
?>

<h1 class="Headline">K�nyvt�rak</h1>

<p class="TextNormal"><b><?=$two_dir_up?></b><br>
- HTDOCS / Webk�nyvt�r gy�kere (wwwroot)<br>
- LightTPD / LightTPD webszerver f�jljai<br>
- MySQL / MySQL adatb�zis-szerver f�jljai<br>
- MiniPerl / Cs�kkentett Perl-k�rnyezet f�jljai<br>
- phpMyAdmin / MySQL WebAdmin f�jljai<br>
- PHP / PHP-k�rnyezet f�jljai<br>
- TMP / Ideiglenes f�jlok k�nyvt�ra</p>

<h1 class="Headline">Szolg�ltat�sok telep�t�se / elt�vol�t�sa </h1>

<p class="TextNormal"><b>Szolg�ltat�sok telep�t�se:</b><br>
'<?=$two_dir_up?>Install_services.exe'</p>

<p class="TextNormal"><b>Szolg�ltat�sok elt�vol�t�sa:</b><br>
'<?=$two_dir_up?>Remove_services.exe'</p>

<h1 class="Headline">Konfigur�ci�s f�jlok</h1>

<p class="TextNormal"><b>LightTPD - Alap�rtelmezett be�ll�t�sok:</b><br>
'<?=$two_dir_up?>LightTPD\conf\lighttpd-inc.conf'</p>

<p class="TextNormal"><b>LightTPD - Szolg�ltat�sk�nt futtatva:</b><br>
'<?=$two_dir_up?>LightTPD\conf\lighttpd-srv.conf'</p>

<p class="TextNormal"><b>LightTPD - Programk�nt futtatva:</b><br>
'<?=$two_dir_up?>LightTPD\conf\lighttpd-prg.conf'</p>

<p class="TextNormal"><b>LightTPD - Server-tag inform�ci�k:</b><br>
'<?=$two_dir_up?>LightTPD\conf\lighttpd-tag.conf'</p>

<p class="TextNormal"><b>MySQL adatb�zis-szerver be�ll�t�sai:</b><br>
'<?=$two_dir_up?>MySQL\my.ini'</p>

<p class="TextNormal"><b>PHP-k�rnyezet be�ll�t�sai:</b><br>
'<?=$two_dir_up?>PHP\php.ini'</p>

<h1 class="Headline">phpMyAdmin bel�p�s - MySQL</h1>

<p class="TextNormal"><b>URL: <a target="_blank"
href="../phpmyadmin/">http://<?=$_SERVER["HTTP_HOST"]?>/phpmyadmin/</a><br>
Felhaszn�l�i n�v:</b> 'root'<br>
<font color="red">A privil�giumnak alap�rtelmez�sben nincs jelszava!</font></p>

<?php
stdfoot();
?>