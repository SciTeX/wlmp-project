<?php
//// -- CONTACTS FILE -- ////

/***#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-#***\
\ W |     WLMP PROJECT - Portal System v1.0     | W /
/ L | - - - - - - - - - - - - - - - - - - - - - | L \
\ M |          Copyright (C) 2006-2010.         | M /
/ P |      WLMP Project TEAM / D-Club Soft.     | P \
\***#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-#***/

/* -- INCLUDE CORE -- */
include("include/wlmp.php");

if ($lng == "1") {
  $page_title = "Contacts";
  $cont1 = "Contacts";
  $cont2 = "Members of Project";
  $cont3 = "G�bor&nbsp;De�";
  $cont4 = "Developer";
  $cont5 = "S�ndor&nbsp;Nemes";
  $cont6 = "English Translation, English Support";
  $cont7 = "�d�m&nbsp;T�ri-Kov�ts";
  $cont8 = "Official tester";
} else {
  $page_title = "El�rhet�s�gek";
  $cont1 = "El�rhet�s�gek";
  $cont2 = "Project r�sztvev�i";
  $cont3 = "De�&nbsp;G�bor";
  $cont4 = "Fejleszt�";
  $cont5 = "Nemes&nbsp;S�ndor";
  $cont6 = "Angol ford�t�s, angol nyelv� t�mogat�s";
  $cont7 = "T�ri-Kov�ts&nbsp;�d�m";
  $cont8 = "Hivatalos tesztel�";
}

stdhead();

?>

<h1 class="Headline"><?=$cont1?></h1>

<p class="TextNormal">

<table border="0">
<tr>
  <td class="TextNormal"><b>URL:</b></td>
  <td class="TextNormal"><a href="http://hu.wlmp-project.net/">http://hu.wlmp-project.net/</a></td>
</tr>

<tr>
  <td class="TextNormal"><b>E-mail:</b></td>
  <td class="TextNormal"><a href="mailto:support@wlmp-project.net">support@wlmp-project.net</a></td>
</tr>
</table>

</p>

<h1 class="Headline"><?=$cont2?></h1>

<p class="TextNormal">

<table border="0">
<tr>
  <td class="TextNormal"><b><?=$cont3?></b></td>
  <td class="TextNormal" width="100%"><?=$cont4?></td>
</tr>

<tr>
  <td class="TextNormal"><b><?=$cont5?></b></td>
  <td class="TextNormal"><?=$cont6?></td>
</tr>

<tr>
  <td class="TextNormal"><b><?=$cont7?></b></td>
  <td class="TextNormal"><?=$cont8?></td>
</tr>
</table>

</p>

<?php
stdfoot();
?>