<?php
//// -- RELEASE DATA FILE -- ////

/***#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-#***\
\ W |     WLMP PROJECT - Portal System v1.0     | W /
/ L | - - - - - - - - - - - - - - - - - - - - - | L \
\ M |          Copyright (C) 2006-2010.         | M /
/ P |      WLMP Project TEAM / D-Club Soft.     | P \
\***#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-#***/

/* -- SET RELEASE VARIABLES -- */

$rdate = "2010-09-24";
$ver   = "1.1.7";
$ptype = "Standard Edition";
$sub   = "1174";
$auth  = "WLMP Project TEAM / D-Club Soft.";
$plng  = "Hungarian (Magyar)";
$plat  = "Win2k / XP / 2k3";

$pcont = " - LightTPD 1.4.28-1\n" .
         " - MySQL 5.0.91\n" .
         " - PHP 5.2.14\n" .
         " - MiniPerl 5.10.1\n" .
         " - OpenSSL 0.9.8o\n" .
         " - phpMyAdmin 2.11.11";