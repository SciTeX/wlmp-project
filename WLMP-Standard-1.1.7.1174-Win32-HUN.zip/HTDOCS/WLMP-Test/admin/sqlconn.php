<?php
//// -- MYSQL CONNECTION RECOVER FILE -- ////

/***#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-#***\
\ W |     WLMP PROJECT - Portal System v1.0     | W /
/ L | - - - - - - - - - - - - - - - - - - - - - | L \
\ M |          Copyright (C) 2006-2009.         | M /
/ P |      WLMP Project TEAM / D-Club Soft.     | P \
\***#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-#***/

/* -- GET MYSQL VARIABLES -- */
$wlmp_conf_file = "../include/config.php";

include($wlmp_conf_file);

if (empty($_POST["name"])) {
  die("MySQL username is empty!");
} else {
  $myuser = $_POST["name"];
}

if (empty($_POST["pwd"])) {
  die("MySQL password is empty!");
} else {
  $mypwd = $_POST["pwd"];
}

$ref = $_SERVER["HTTP_REFERER"];

if (file_exists($wlmp_conf_file)) {
  $l_wlmp = fopen($wlmp_conf_file, "r");
  $lt_wlmp = fread($l_wlmp, filesize($wlmp_conf_file));
  fclose($l_wlmp);
  $lt_wlmp = ereg_replace("mysql_user = \"" . $mysql_user . "\";", "mysql_user = \"" . $myuser . "\";", $lt_wlmp);
  $lt_wlmp = ereg_replace("mysql_pass = \"" . $mysql_pass . "\";", "mysql_pass = \"" . $mypwd . "\";", $lt_wlmp);
  $l_wlmp = fopen("$wlmp_conf_file", "w");
  fwrite($l_wlmp, $lt_wlmp);
  fclose($l_wlmp);
}

header("Refresh: 2; url=" . $ref);

print("The new settings are saved...");

