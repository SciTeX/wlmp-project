<?php
/* Theme information */
$theme_name = 'Very small';
$theme_version = 2;
$theme_generation = 2;
?>
