<?php
/* vim: set expandtab sw=4 ts=4 sts=4: */
/**
 * @version $Id$
 */

/**
 *
 */
include_once './libraries/engines/bdb.lib.php';

class PMA_StorageEngine_berkeleydb extends PMA_StorageEngine_bdb
{
}

?>
