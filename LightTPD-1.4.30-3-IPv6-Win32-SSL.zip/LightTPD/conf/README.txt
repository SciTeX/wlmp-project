============================
LightTPD configuration files
============================

lighttpd.conf:
  default configuration file

service.conf:
  logging configuration for service

server-tag.conf:
  server tag information

mimetype.conf:
  mimetype mapping list

variables.conf
  path variables (genereated by GenVars.cmd)

auth.user:
  backend authentication userfile (use with mod_auth)