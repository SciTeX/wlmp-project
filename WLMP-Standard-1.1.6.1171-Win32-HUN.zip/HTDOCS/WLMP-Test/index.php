<?php
//// -- INDEX FILE -- ////

/***#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-#***\
\ W |     WLMP PROJECT - Portal System v1.0     | W /
/ L | - - - - - - - - - - - - - - - - - - - - - | L \
\ M |          Copyright (C) 2006-2009.         | M /
/ P |      WLMP Project TEAM / D-Club Soft.     | P \
\***#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-#***/

/* -- INCLUDE CORE -- */
include("include/wlmp.php");
stdhead();

include("include/reldata.php");

?>

<h1 class="Headline">Gratul�lunk!</h1>

<p class="TextNormal">A WLMP Project telep�t�se sikeresen befejez�d�tt az �n g�p�n.</p>

<p class="TextNormal">A komponensekr�l a <a href="settings.php">
<b>Be�ll�t�sok</b></a> men�pont alatt tal�lhat� b�vebb inform�ci�.</p>

<h1 class="Headline">Inform�ci�k a telep�tett verzi�r�l</h1>

<p class="TextNormal"><pre>
Release Date: <?=$rdate . "\n"?>
Version: <?=$ver . "\n"?>
Type: <?=$ptype . "\n"?>
Build: <?=$sub . "\n"?>
Author: <?=$auth . "\n"?>
Language: <?=$plng . "\n"?>
Platform: <?=$plat . "\n"?>

Contents of package:
====================

<?=$pcont?>
</pre></p>

<?php
stdfoot();
?>