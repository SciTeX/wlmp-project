<?
$url = "../";
header("Refresh: 0; url=$url");
?>