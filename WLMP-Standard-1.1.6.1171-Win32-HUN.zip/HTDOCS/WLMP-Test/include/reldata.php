<?php
//// -- RELEASE DATA FILE -- ////

/***#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-#***\
\ W |     WLMP PROJECT - Portal System v1.0     | W /
/ L | - - - - - - - - - - - - - - - - - - - - - | L \
\ M |          Copyright (C) 2006-2009.         | M /
/ P |      WLMP Project TEAM / D-Club Soft.     | P \
\***#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-#***/

/* -- SET RELEASE VARIABLES -- */

$rdate = "2009-03-20";
$ver   = "1.1.6";
$ptype = "Standard Edition";
$sub   = "1171";
$auth  = "WLMP Project TEAM / D-Club Soft.";
$plng  = "Hungarian (Magyar)";
$plat  = "Win2k / XP / 2k3";

$pcont = " - LightTPD 1.4.22\n" .
         " - MySQL 5.0.77\n" .
         " - PHP 5.2.9-1\n" .
         " - MiniPerl 5.8.8\n" .
         " - OpenSSL 0.9.8j\n" .
         " - phpMyAdmin 2.11.9.4";