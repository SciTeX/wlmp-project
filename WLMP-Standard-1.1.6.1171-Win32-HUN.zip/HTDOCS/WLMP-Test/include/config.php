<?php
//// -- CONFIGURATION FILE -- ////

/***#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-#***\
\ W |     WLMP PROJECT - Portal System v1.0     | W /
/ L | - - - - - - - - - - - - - - - - - - - - - | L \
\ M |          Copyright (C) 2006-2009.         | M /
/ P |      WLMP Project TEAM / D-Club Soft.     | P \
\***#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-#***/

/* -- Defaults -- */

$site_on    = "true";              // Site Online: "true/false"

$author     = "WLMP Project TEAM"; // Site Author Name

$nmsite_hu  = "WLMP Project";      // Hungarian Site Name
$nmsite_en  = "WLMP Project";      // English Site Name

$nmhdr_hu   = "Verzi� inform�ci�k";
                                   // Right HeadLine Box Hungarian Name
$nmhdr_en   = "Version Information";    
                                   // Right HeadLine Box English Name

/* -- Directories -- */

$img_path   = "images/";           // Images Directory Path
$admin_path = "admin/";            // Administration Source Directory Path
$downloads  = "downloads/";        // Downloads Directory Path

/* -- MySQL Connection -- */

$mysql_host = "localhost";         // Hostname
$mysql_user = "root";              // Username
$mysql_pass = "";                  // Password

$mysql_db   = "wlmp";              // Database Name

/* -- Contents -- */

$headlogo   = "true";              // Visible Logo Head: "true/false"
$menu       = "true";              // Visible Menu: "true/false"
$lngsel     = "false";             // Visible Language Selection: "true/false"

$xtr_left   = "false";             // Visible Left Extra Content: "true/false"
$xtr_right  = "true";              // Visible Right Extra Content: "true/false"

$hdr_box    = "true";              // Visible Right HeadLine Box: "true/false"
$links      = "true";              // Visible Links: "true/false"

/* -- Style -- */

$style      = "style.css";         // CSS Style Filename

$div_style  = "width: 90%; border: 2px solid #909090; color: #FFFFFF;";
                                   // DIV Style Script
$div_align  = "center";            // DIV Align: "left/center/right"

$logo_bg    = "logo_bg.png";       // Background Filename of Logo
$logo_left  = "logo_left.png";     // Left Logo Filename
$logo_right = "logo_right.png";    // Right Logo Filename

?>
