<?php
//// -- PORTAL CORE FILE -- ////

/***#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-#***\
\ W |     WLMP PROJECT - Portal System v1.0     | W /
/ L | - - - - - - - - - - - - - - - - - - - - - | L \
\ M |          Copyright (C) 2006-2009.         | M /
/ P |      WLMP Project TEAM / D-Club Soft.     | P \
\***#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-#***/

/* -- INCLUDE CONFIGFILE -- */
include("config.php");

/* -- GET & SET LANGUAGE -- */
if (empty($_GET["lang"])) {
  $lng = "0";
} else {
  if ($_GET["lang"] == "en") {
    $lng = "1";
  } else {
    $lng = "0";
  }
}

/* -- SET FUNCTIONS -- */

// SITE ONLINE CHECK
function chk_on() {
  global $site_on;
  if ($site_on == "false") {
    die("<b>Karbantart�s alatt! / Under construction!</b>");
  }
}

// DATABASE
function db_open() {
  global $mysql_host, $mysql_user, $mysql_pass, $mysql_db, $connect, $admin_path, $_POST;
  $connect = mysql_connect($mysql_host, $mysql_user, $mysql_pass);
  if (!$connect) {
    if (empty($_POST["name"])) {
      $get_user = $mysql_user;
    } else {
      $get_user = $_POST["name"];
    }

    die("<b><font color=\"red\">Nem siker�lt kapcsol�dni az adatb�zis szerverhez! / Could not connect to the MySQL database server!</font></b>\n\n" .
        "<h1 class=\"Headline\">MySQL hozz�f�r�s helyre�ll�t�sa / MySQL Access Recovery</h1>\n\n" .
        "<form method=\"post\" name=\"sqlconn\" action=\"./" . $admin_path . "sqlconn.php\">\n\n" .
        "<table border=\"0\">\n" .
        "<tr>\n" .
        "  <td class=\"TextNormal\"><b>Felhaszn�l�n�v<br>Username</b></td>\n" .
        "  <td class=\"TextNormal\"><input type=\"text\" id=\"name\" name=\"name\" value=\"" . $get_user . "\"></td>\n" .
        "</tr>\n\n" .
        "<tr>\n" .
        "  <td class=\"TextNormal\"><b>Jelsz�<br>Password</b></td>\n" .
        "  <td class=\"TextNormal\"><input type=\"password\" id=\"pwd\" name=\"pwd\"></td>\n" .
        "</tr>\n\n" .
        "<tr>\n" .
        "  <td class=\"TextNormal\" colspan=\"2\"><input type=\"submit\" value=\"Csatlakoz�s / Connect\" class=btn></td>\n" .
        "<tr>\n" .
        "</table>\n\n" .
        "</form>\n\n" .
        "</html>\n");
  }

  if (!mysql_select_db($mysql_db, $connect)) {
    die("<b><font color=\"red\">Nem siker�lt kiv�lasztani az adatb�zist! / Could not select the database!</font></b>\n\n" .
        "</html>\n");
  }
}

function db_close() {
  global $connect;
  mysql_close($connect);
}

// MENU
function get_menu() {
  global $lng;
  db_open();
  print("  <table width=\"173\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n\n");
  $res = mysql_query("SELECT * FROM menu WHERE visible='yes' ORDER BY id");
  while ($row = mysql_fetch_array($res)) {
    $id = $row["id"];
    $padding = $row["padding"];
    $target = $row["target"];
    if ($lng == "1") {
      $name = $row["name_eng"];
      $url = $row["url_eng"];
    } else {
      $name = $row["name_hun"];
      $url = $row["url_hun"];
    }

    if ($padding == "yes") {
      $pd = "20";
    } else {
      $pd = "10";
    }

    if ($target == "yes") {
      $tg = "target=\"_blank\"";
    } else {
      $tg = "";
    }

    print("  <tr>\n");
    print("    <td valign=\"middle\" class=\"WhiteLine\"><img src=\"images/spacer.gif\" width=\"1\" height=\"1\"></td>\n");
    print("  </tr>\n\n");
    print("  <tr>\n");
    print("    <td width=\"173\" valign=\"middle\"><a href=\"" . $url . "\" " . $tg . "class=\"menu\" style=\"height: 14px; padding-left: " . $pd . "px\">" . $name . "</a></td>\n");
    print("  </tr>\n\n");
  }

  db_close();
  print("  <tr>\n");
  print("    <td valign=\"middle\" class=\"WhiteLine\"><img src=\"images/spacer.gif\" width=\"1\" height=\"1\"></td>\n");
  print("  </tr>\n\n");
  print("  </table>\n\n");

}

// LANGUAGE SELECTION
function sel_lang() {
  global $lng, $img_path, $_SERVER;
  if ($lng == "1") {
    $hdt = "Language / Nyelv";
    $lnk1 = $_SERVER["PHP_SELF"];
    $sel1 = "Hungarian (Magyar)";
    $pic1 = "hu.png";
    $lnk2 = $_SERVER["PHP_SELF"] . "?lang=en";
    $sel2 = "English (Angol)";
    $pic2 = "en.png";
  } else {
    $hdt = "Nyelv / Language";
    $lnk1 = $_SERVER["PHP_SELF"] . "?lang=en";
    $sel1 = "Angol (English)";
    $pic1 = "en.png";
    $lnk2 = $_SERVER["PHP_SELF"];
    $sel2 = "Magyar (Hungarian)";
    $pic2 = "hu.png";
  }

  print("  <table border=\"0\" width=\"100%\">\n\n");
  print("  <tr>\n");
  print("    <td align=\"center\" class=\"NewsHeadline\">\n");
  print("    <table border=\"0\" width=\"100%\">\n\n");
  print("    <tr>\n");
  print("      <td class=\"NewsNormal\" colspan=\"2\" align=\"center\"><b>" . $hdt . "</b></td>\n");
  print("    </tr>\n\n");
  print("    <tr>\n");
  print("      <td class=\"WhiteLine\" colspan=\"2\" height=\"1\"><img src=\"" . $img_path . "spacer.gif\" width=\"1\" height=\"1\"></td>\n");
  print("    </tr>\n\n");
  print("    <tr>\n");
  print("      <td><a href=\"" . $lnk1 . "\"><img border=\"0\" src=\"" . $img_path . $pic1 . "\" align=\"right\"></a></td>\n");
  print("      <td class=\"NewsNormal\"><a href=\"" . $lnk1 . "\">" . $sel1 . "</a></td>\n");
  print("    </tr>\n\n");
  print("    <tr>\n");
  print("      <td class=\"WhiteLine\" colspan=\"2\" height=\"1\"><img src=\"" . $img_path . "spacer.gif\" width=\"1\" height=\"1\"></td>\n");
  print("    </tr>\n\n");
  print("    <tr>\n");
  print("      <td><a href=\"" . $lnk2 . "\"><img border=\"0\" src=\"" . $img_path . $pic2 ."\" align=\"right\"></a></td>\n");
  print("      <td class=\"NewsNormal\"><a href=\"" . $lnk2 . "\">" . $sel2 . "</a></td>\n");
  print("    </tr>\n\n");
  print("    <tr>\n");
  print("      <td class=\"WhiteLine\" colspan=\"2\" height=\"1\"><img src=\"" . $img_path . "spacer.gif\" width=\"1\" height=\"1\"></td>\n");
  print("    </tr>\n\n");
  print("    </table>\n");
  print("    </td>\n");
  print("  </tr>\n\n");
  print("  </table>\n");
}

// EXTRA LEFT CONTENT
function left_extra() {
  print("  <table border=\"0\" width=\"100%\">\n\n");
  print("  <tr>\n");
  print("    <td align=\"center\">STATIC</td>\n");
  print("  </tr>\n");
  print("  </table>\n");
}

// EXTRA RIGHT CONTENT
function right_extra() {
  global $img_path;
  print("  <table border=\"0\" width=\"100%\">\n");
  print("  <tr>\n");
  print("    <td align=\"center\" class=\"TextNormal\"><b>Powered by</b></td>\n");
  print("  </tr>\n\n");
  db_open();
  $res = mysql_query("SELECT * FROM powered WHERE visible='yes' ORDER BY id");
  while ($row = mysql_fetch_array($res)) {
    $name = $row["name"];
    $picture = $row["picture"];
    $url = $row["url"];
    print("  <tr>\n");
    print("    <td align=\"center\"><a href=\"" . $url . "\"target=\"_blank\"><img\n");
    print("    border=\"0\" src=\"" . $img_path . $picture . "\" alt=\"" . $name . "\"></a></td>\n");
    print("  </tr>\n\n");
  }

  db_close();
  print("  <tr>\n");
  print("    <td align=\"center\" class=\"TextNormal\">&nbsp;</td>\n");
  print("  </tr>\n\n");
  print("  </table>\n");
}

// RIGHT HEADLINE BOX
function hdrbox() {
  global $lng, $nmhdr_hu, $nmhdr_en, $img_path;
  print("  <tr>\n");
  print("    <td height=\"26\" class=\"BoxTitle\"><p class=\"BoxTitle\">");
  if ($lng == "1") {
    print($nmhdr_en);
  } else {
    print($nmhdr_hu);
  }

  print("</p></td>\n");
  print("  </tr>\n\n");
  print("  <tr>\n");
  print("    <td class=\"WhiteLine\"><img src=\"" . $img_path . "spacer.gif\" width=\"1\" height=\"1\"></td>\n");
  print("  </tr>\n\n");
}

// HEADLINE
function stdhead() {
  global $_SERVER, $lng, $nmsite_hu, $nmsite_en, $page_title, $img_path, $style, $div_align, $div_style, $headlogo, $logo_bg, $logo_left, $logo_right, $menu, $lngsel, $xtr_left;
  if ($lng == "1") {
    $charset = "iso-8859-1";
    $nmlang = "en";
  } else {
    $charset = "iso-8859-2";
    $nmlang = "hu";
  }

  print("<!xml version=\"1.0\" encoding=\"" . $charset . "\">\n");
  print("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\"\n");
  print("         \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n");
  print("<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"" . $nmlang . "\" lang=\"" . $nmlang . "\">\n\n");
  print("<head>\n");
  if ($lng == "1") {
    $site_name = $nmsite_en;
  } else {
    $site_name = $nmsite_hu;
  }

  if (empty($page_title)) {
    print("<title>$site_name</title>\n");
  } else {
    print("<title>$site_name / $page_title</title>\n");
  }

  print("<link href=\"" . $img_path . $style . "\" rel=\"stylesheet\" media=\"screen\">\n");
  print("</head>\n\n");
  chk_on();
  db_open();
  db_close();
  print("<body>\n\n");
  print("<div align=\"" . $div_align . "\">\n");
  print("<div style=\"" . $div_style . "\">\n\n");
  print("<table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\n\n");
  if (empty($headlogo)) {
    $hdl = "1";
  } else {
    if ($headlogo == "true") {
      $hdl = "1";
    } else {
      $hdl = "0";
    }
  }

  if ($hdl == "1") {
    print("<tr>\n");
    print("  <td colspan=\"3\">\n");
    print("  <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" background=\"" . $img_path . $logo_bg . "\">\n\n");
    print("  <tr>\n");
    print("    <td><img border=\"0\" src=\"" . $img_path . $logo_left . "\" align=\"left\"></td>\n");
    print("    <td><img border=\"0\" src=\"" . $img_path . $logo_right . "\" align=\"right\"></td>\n");
    print("  </tr>\n\n");
    print("  </table>\n");
    print("  </td>\n");
    print("</tr>\n\n");
  }

  print("<tr valign=\"top\">\n");
  print("  <td class=\"Columns\">\n");
  if (empty($menu)) {
    get_menu();
  } else {
    if ($menu == "false") {
    } else {
      get_menu();
    }
  }

  if (empty($lngsel)) {
    sel_lang();
  } else {
    if ($lngsel == "false") {
    } else {
      sel_lang();
    }
  }

  if (empty($xtr_left)) {
    left_extra();
  } else {
    if ($xtr_left == "false") {
    } else {
      left_extra();
    }
  }

  print("  </td>\n");
  print("  <td class=\"Content\">\n\n");
  print("<!-- *** Begin of Content: \"" . $_SERVER["PHP_SELF"] . "\" | Language ID: \"" . $lng . "\" *** -->\n");
}

// FOOTLINE
function stdfoot() {
  global $_SERVER, $lng, $img_path, $hdr_box, $xtr_right, $author, $site_mail;
  print("<!-- *** End of Content: \"" . $_SERVER["PHP_SELF"] . "\" | Language ID: \"" . $lng . "\" *** -->\n\n");
  print("  </td>\n");
  print("  <td class=\"Columns\">\n");
  print("  <table width=\"173\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n\n");
  print("  <tr>\n");
  print("    <td class=\"WhiteLine\"><img src=\"images/spacer.gif\" width=\"1\" height=\"1\"></td>\n");
  print("  </tr>\n\n");
  if (empty($hdr_box)) {
    hdrbox();
  } else {
    if ($hdr_box == "false") {
    } else {
      hdrbox();
    }
  }

  print("  <tr>\n");
  print("    <td class=\"BoxNewsMessage\">\n");
  print("    <table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">\n\n");
  include("reldata.php");
  if ($lng == "1") {
    $text = $row["text_eng"];
    $url = "http://en.wlmp-project.net/downloads.php?cat=wlmp&type=stable";
    $cont = "Check for update";
  } else {
    $text = $row["text_hun"];
    $url = "http://hu.wlmp-project.net/downloads.php?cat=wlmp&type=stable";
    $cont = "Friss�t�s keres�se";
  }

  print("    <tr width=\"100%\">\n");
  print("      <td class=\"NewsNormal\">[" . $rdate . "]<br><b>WLMP - " . $ptype ."<br>\n");
  print("      Version " . $ver . "<br>\n");
  print("      Build: " . $sub . "</b></td>\n");
  print("    </tr>\n\n");
  print("    <tr>\n");
  print("      <td class=\"NewsNormal\" align=\"right\"><a href=\"" . $url . "\"><b>" . $cont . " &gt;&gt;</b></a></td>\n");
  print("    </tr>\n\n");
  print("    <tr>\n");
  print("      <td class=\"WhiteLine\"><img src=\"images/spacer.gif\" width=\"1\" height=\"1\"></td>\n");
  print("    </tr>\n\n");
  if ($lng == "1") {
    $siterun = "Version of components";
    $chk_os = "Operating System";
    $websrv = "Webserver";
  } else {
    $siterun = "Komponensek verzi�i";
    $chk_os = "Oper�ci�s rendszer";
    $websrv = "Webszerver";
  }

  print("    <tr>\n");
  print("      <td class=\"NewsHeadline\">" . $siterun . ":</td>\n");
  print("    </tr>\n\n");
  print("    <tr>\n");
  if (PHP_OS == "WINNT") {
    $wmi = new COM("WinMgmts:{impersonationLevel=impersonate}");
    $opsys = $wmi -> ExecQuery("SELECT * FROM Win32_OperatingSystem");
    print("      <td class=\"NewsNormal\"><b>" . $chk_os . ":</b><br>\n");
    foreach($opsys as $os) {
    print("      " . $os -> caption . "</td>\n");
    }

    print("    </tr>\n\n");
  }

  print("      <td class=\"NewsNormal\"><b>" . $websrv . ":</b><br>\n");
  print("      " . $_SERVER['SERVER_SOFTWARE'] . "</td>\n");
  print("    </tr>\n\n");
  print("    <tr>\n");
  print("      <td class=\"NewsNormal\"><b>PHP:</b><br>\n");
  print("      " . phpversion() . "</td>\n");
  print("    </tr>\n\n");
  print("    <tr>\n");
  print("      <td class=\"NewsNormal\"><b>MySQL:</b><br>\n");
  db_open();
  print("      " . mysql_get_server_info() . "</td>\n");
  db_close();
  print("    </tr>\n\n");
  print("    <tr>\n");
  print("      <td class=\"WhiteLine\"><img src=\"images/spacer.gif\" width=\"1\" height=\"1\"></td>\n");
  print("    </tr>\n\n");
  print("    <tr>\n");
  if ($lng == "1") {
    print("      <td class=\"NewsHeadline\">Links:</td>\n");
  } else {
    print("      <td class=\"NewsHeadline\">Linkek:</td>\n");
  }
  
  print("    </tr>\n\n");
  db_open();
  $res = mysql_query("SELECT * FROM links WHERE visible='yes' ORDER BY id");
  while ($row = mysql_fetch_array($res)) {
    if ($lng == "1") {
      $name = $row["name_eng"];
      $url = $row["url_eng"];
    } else {
      $name = $row["name_hun"];
      $url = $row["url_hun"];
    }

    print("    <tr>\n");
    print("      <td class=\"NewsNormal\"><a href=\"" . $url . "\"\n");
    print("      target=\"_blank\"><b>" . $name . "</b></a></td>\n");
    print("    </tr>\n\n");
  }

  db_close();
  print("    </table>\n");
  print("    </td>\n");
  print("  </tr>\n\n");
  print("  <tr>\n");
  print("    <td class=\"WhiteLine\"><img src=\"images/spacer.gif\" width=\"1\" height=\"1\"></td>\n");
  print("  </tr>\n\n");
  print("  </table>\n");
  if (empty($xtr_right)) {
    right_extra();
  } else {
    if ($xtr_right == "false") {
    } else {
      right_extra();
    }
  }

  print("  </td>\n");
  print("</tr>\n\n");
  print("<tr>\n");
  print("  <td class=\"NewsNormal\" colspan=\"3\" align=\"center\"><b>Copyright (C) 2006-2009.<br>\n");
  print("  <a href=\"http://hu.wlmp-project-net/\">" . $author . "</a></b></td>\n");
  print("</tr>\n\n");
  print("</table>\n\n");
  print("</div>\n");
  print("</div>\n\n");
  print("</body>\n\n");
  print("</html>\n");
}

?>
