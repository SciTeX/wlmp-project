<?php
//// -- DOCUMENTATION FILE -- ////

/***#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-#***\
\ W |     WLMP PROJECT - Portal System v1.0     | W /
/ L | - - - - - - - - - - - - - - - - - - - - - | L \
\ M |          Copyright (C) 2006-2009.         | M /
/ P |      WLMP Project TEAM / D-Club Soft.     | P \
\***#-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-#***/

/* -- INCLUDE CORE -- */
include("include/wlmp.php");

if ($lng == "1") {
  $page_title = "Documentation";
} else {
  $page_title = "Dokument�ci�";
}

stdhead();

?>

<h1 class="Headline">LightTPD</h1>

<p class="TextNormal"><a href="http://trac.lighttpd.net/trac/wiki/"
target="_blank">http://trac.lighttpd.net/trac/wiki/</a></p>

<h1 class="Headline">MySQL</h1>

<p class="TextNormal"><a href="http://dev.mysql.com/doc/"
target="_blank">http://dev.mysql.com/doc/</a></p>

<h1 class="Headline">PHP</h1>

<p class="TextNormal"><a href="http://www.php.net/docs.php"
target="_blank">http://www.php.net/docs.php</a></p>

<h1 class="Headline">Perl</h1>

<p class="TextNormal"><a href="http://www.perl.com/pub/q/documentation"
target="_blank">http://www.perl.com/pub/q/documentation</a></p>

<h1 class="Headline">OpenSSL</h1>

<p class="TextNormal"><a href="http://www.openssl.org/docs/"
target="_blank">http://www.openssl.org/docs/</a></p>

<h1 class="Headline">phpMyAdmin</h1>

<p class="TextNormal"><a href="http://www.phpmyadmin.net/documentation/"
target="_blank">http://www.phpmyadmin.net/documentation/</a></p>

<?php
stdfoot();
?>