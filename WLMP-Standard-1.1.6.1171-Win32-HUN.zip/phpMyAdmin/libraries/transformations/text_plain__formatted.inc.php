<?php
/* vim: set expandtab sw=4 ts=4 sts=4: */
/**
 *
 * @version $Id: text_plain__formatted.inc.php 10142 2007-03-20 10:32:13Z cybot_tm $
 */

/**
 *
 */
function PMA_transformation_text_plain__formatted($buffer, $options = array(), $meta = '') {
    return $buffer;
}

?>
