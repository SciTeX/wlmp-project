============================
LightTPD configuration files
============================

lighttpd-inc.conf:
  default configuration file

lighttpd-srv.conf:
  logging configuration for service

lighttpd-tag.conf:
  server tag information

lighttpd-auth.user:
  backend authentication userfile (use with mod_auth)
