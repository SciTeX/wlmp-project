<div class="footnote">
<?php echo <<<EOS
Powered By: XCache {$xcache_version}, {$xcache_modules}
EOS;
?>
</div>

</body>
</html>
